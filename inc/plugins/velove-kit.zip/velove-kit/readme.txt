=== Velove Kit ===
Contributors: idenovasi
Tags: cookie, sidebar, sticky, pinterest, layouts, author, signature, social, share
Requires at least: 4.6
Tested up to: 5.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Provides custom features to Velove WordPress themes.

== Description ==

This plugin will enable custom features to Velove WordPress themes. The custom features will extend your WordPress website.

**Features List:**

* Author profile social
* Cookie
* Pinterest button
* Custom signature
* Sticky sidebar
* Social share

== Changelog ==

= 1.0.0 - July 05, 2017 =
- Initial release
