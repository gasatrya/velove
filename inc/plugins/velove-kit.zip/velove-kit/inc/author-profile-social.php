<?php
/**
 * Register custom social info fields.
 */

function bk_author_profile_extra_social( $contactmethods ) {
	$contactmethods['twitter']     = esc_html__( 'Twitter URL', 'velove-kit' );
	$contactmethods['facebook']    = esc_html__( 'Facebook URL', 'velove-kit' );
	$contactmethods['gplus']       = esc_html__( 'Google Plus URL', 'velove-kit' );
	$contactmethods['instagram']   = esc_html__( 'Instagram URL', 'velove-kit' );
	$contactmethods['pinterest']   = esc_html__( 'Pinterest URL', 'velove-kit' );
	$contactmethods['linkedin']    = esc_html__( 'Linkedin URL', 'velove-kit' );
	$contactmethods['dribbble']    = esc_html__( 'Dribbble URL', 'velove-kit' );

	return $contactmethods;
}
add_filter( 'user_contactmethods', 'bk_author_profile_extra_social' );
